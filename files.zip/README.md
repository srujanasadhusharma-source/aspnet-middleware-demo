# ASP.NET Core Middleware and Swagger Demo

A small ASP.NET Core Web API that shows how the middleware pipeline works.

- Custom `RequestTimingMiddleware` measures and logs how long each request takes.
- Swagger / OpenAPI is enabled for documentation and testing.
- Two sample endpoints: `GET /api/products` and `GET /api/products/{id}`.

## Run

```
dotnet run
```

Then open `/swagger` in your browser (for example `http://localhost:5000/swagger`; the exact port is shown in the terminal). Call an endpoint and check the terminal to see the timing log.
