using MiddlewareDemo;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Custom middleware: logs how long each request takes
app.UseMiddleware<RequestTimingMiddleware>();

app.UseSwagger();
app.UseSwaggerUI();

var products = new[]
{
    new Product(1, "Laptop", 55000m),
    new Product(2, "Mouse", 500m),
    new Product(3, "Keyboard", 1200m)
};

app.MapGet("/api/products", () => products)
   .WithName("GetProducts");

app.MapGet("/api/products/{id:int}", (int id) =>
    products.FirstOrDefault(p => p.Id == id) is Product p
        ? Results.Ok(p)
        : Results.NotFound())
   .WithName("GetProductById");

app.Run();

record Product(int Id, string Name, decimal Price);
